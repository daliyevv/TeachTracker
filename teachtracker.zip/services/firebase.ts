import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore, doc, getDocFromServer } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import firebaseConfig from "../firebase-applet-config.json";

// Yangi loyiha o'rnatilganda eski to'xtatilgan holatni tozalaymiz
if (typeof window !== 'undefined') {
  const currentKey = firebaseConfig.apiKey || "";
  const lastKey = localStorage.getItem('firebase_last_key');
  if (lastKey !== currentKey) {
    localStorage.removeItem('firebase_suspended');
    sessionStorage.removeItem('reloaded_after_suspension');
    localStorage.setItem('firebase_last_key', currentKey);
  }
}

export const isFirebaseConfigured = !!(
  firebaseConfig.apiKey &&
  firebaseConfig.projectId
);

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

/* CRITICAL: Passing firestoreDatabaseId is mandatory for provisioned database instances */
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

// Connection testing as mandated by skill guidelines
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Firestore connection test passed.");
    return true;
  } catch (error: any) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Please check your Firebase configuration or internet connection.");
      return false;
    }
    // If doc does not exist, connection is still alive
    if (error?.code === 'not-found' || error?.code === 'permission-denied') {
      console.log("Firestore server reachable (doc or permission checked).");
      return true;
    }
    console.warn("Firestore connection check info:", error?.message || error);
    return true;
  }
}

testFirestoreConnection();

export { app };
